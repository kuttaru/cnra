import React, { useState, useEffect, useMemo, Component } from 'react';
import { initializeApp } from "firebase/app";
import { getDatabase, ref, onValue } from "firebase/database";
import { getFirestore, collection, query, onSnapshot } from "firebase/firestore";

const BuildingIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5m0 0v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
  </svg>
);

const UsersIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
  </svg>
);

const SearchIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
  </svg>
);

const GridIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2V6zM14 6a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V6zM4 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2H6a2 2 0 01-2-2v-2zM14 16a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
  </svg>
);

const ListIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
  </svg>
);

const MapPinIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

const PhoneIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
  </svg>
);

const EyeIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
  </svg>
);

const ChevronLeftIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
  </svg>
);

const ChevronRightIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
  </svg>
);

const XIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
  </svg>
);

const DropletIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 2.69l5.66 5.66a8 8 0 11-11.31 0z" />
  </svg>
);

const BriefcaseIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
  </svg>
);

const CalendarIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
  </svg>
);

const MailIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
  </svg>
);

const RefreshCwIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
  </svg>
);

const HomeIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
  </svg>
);

const ExternalLinkIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
  </svg>
);

const FilterIcon = ({ className = "w-4 h-4" }) => (
  <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2">
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
  </svg>
);

const firebaseConfig = {
  apiKey: "AIzaSyBsiqHxm2A95BGTpWGiIWfFZdzGOO45xgM",
  authDomain: "cnra-b77a5.firebaseapp.com",
  databaseURL: "https://cnra-b77a5-default-rtdb.firebaseio.com",
  projectId: "cnra-b77a5",
  storageBucket: "cnra-b77a5.firebasestorage.app",
  messagingSenderId: "998451989920",
  appId: "1:998451989920:web:348a0aa87c31b2caeee8c5",
  measurementId: "G-WJW511EL90"
};

let app, db, rtdb;
try {
  app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  rtdb = getDatabase(app);
} catch (e) {
  console.warn("Firebase initialized with fallback mode", e);
}

const RAW_MOCK_DATA = {
  "cnra_houses": {
    "house_1791013954821": {
      "address": "Vrinthavan road",
      "familyName": "Velenparambil",
      "houseNumber": "CNRA-218",
      "id": "house_1791013954821",
      "occupancyType": "Owner",
      "locationMark": "Vrinthavan Junction",
      "location": {
        "lat": 10.15476,
        "lng": 76.346723
      },
      "mainPhone": "9447744288",
      "members": {
        "mem_1791013991972": {
          "bloodGroup": "B+",
          "dateOfBirth": "1987-02-23",
          "email": "arun@velenparambil.com",
          "fullName": "Arun Velenparambil",
          "gender": "Male",
          "id": "mem_1791013991972",
          "notes": "Dancer & Cultural Club Lead",
          "occupation": "Developer",
          "phone": "9447744288",
          "photo": "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=250",
          "relationship": "Son"
        },
        "mem_1791014025436": {
          "bloodGroup": "--",
          "dateOfBirth": "1976-02-23",
          "email": "kamalu@cnra.org",
          "fullName": "Kamalu Velenparambil",
          "gender": "Female",
          "id": "mem_1791014025436",
          "notes": "Association Volunteer",
          "occupation": "Teacher",
          "phone": "9447755441",
          "photo": "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=250",
          "relationship": "Spouse"
        },
        "mem_1791017090149": {
          "bloodGroup": "O+",
          "dateOfBirth": "2001-08-14",
          "email": "anila@gmail.com",
          "fullName": "Anila Velenparambil",
          "gender": "Female",
          "id": "mem_1791017090149",
          "notes": "Student",
          "occupation": "Architectural Student",
          "phone": "9847123456",
          "photo": "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=250",
          "relationship": "Daughter"
        }
      }
    },
    "house_1791035844132": {
      "address": "Ambalam road",
      "familyName": "Sankarabhavanam",
      "houseNumber": "CNRA-42",
      "id": "house_1791035844132",
      "occupancyType": "Owner",
      "locationMark": "Temple North Gate",
      "location": {
        "lat": 12.9716,
        "lng": 77.5946
      },
      "mainPhone": "9447744288",
      "members": {
        "mem_1791035856091": {
          "bloodGroup": "O+",
          "dateOfBirth": "1982-11-05",
          "email": "seema@sankarabhavanam.com",
          "fullName": "Seema Sankarabhavanam",
          "gender": "Female",
          "id": "mem_1791035856091",
          "notes": "Treasurer Committee",
          "occupation": "Bank Officer",
          "phone": "9447744288",
          "photo": "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=250",
          "relationship": "Spouse"
        }
      }
    }
  }
};

const calculateAge = (dobString) => {
  if (!dobString) return '';
  const birthDate = new Date(dobString);
  if (isNaN(birthDate.getTime())) return '';
  const today = new Date();
  let age = today.getFullYear() - birthDate.getFullYear();
  const m = today.getMonth() - birthDate.getMonth();
  if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
    age--;
  }
  return age > 0 ? age : '';
};

const normalizeMembers = (membersObj) => {
  if (!membersObj) return [];
  if (Array.isArray(membersObj)) return membersObj;
  if (typeof membersObj === 'object') {
    return Object.keys(membersObj).map(key => ({
      id: key,
      ...membersObj[key]
    }));
  }
  return [];
};

const processHousesData = (raw) => {
  if (!raw) return [];
  let rawList = [];
  if (Array.isArray(raw)) {
    rawList = raw;
  } else if (typeof raw === 'object') {
    if (raw.cnra_houses) {
      rawList = Object.values(raw.cnra_houses);
    } else {
      rawList = Object.values(raw);
    }
  }

  return rawList.map((house, idx) => {
    const rawMembers = normalizeMembers(house?.members);
    const members = rawMembers.map((m, mIdx) => {
      const dob = m.dateOfBirth || m.dob || '';
      const ageVal = m.age || calculateAge(dob);

      const memberPhone = m.phoneNumber || m.phone || '';

      return {
        id: m.id || `mem_${idx}_${mIdx}`,
        fullName: m.fullName || m.name || 'Resident',
        name: m.fullName || m.name || 'Resident',
        relationship: m.relationship || m.relation || 'Family Member',
        gender: m.gender || 'N/A',
        bloodGroup: m.bloodGroup && m.bloodGroup !== '--' ? m.bloodGroup : 'N/A',
        rawBloodGroup: m.bloodGroup || '--',
        dateOfBirth: dob,
        age: ageVal,
        email: m.email || '',
        phone: memberPhone || 'N/A',
        phoneNumber: memberPhone,
        occupation: m.occupation || 'N/A',
        notes: m.notes || '',
        photo: m.photo || m.avatar || ''
      };
    });

    const headMember = members.find(m => 
      (m.relationship || '').toLowerCase().includes('head') || 
      (m.relationship || '').toLowerCase().includes('father')
    ) || members[0] || {};

    // Primary Contact Phone logic:
    // 1. First check Primary Contact Phone field on house
    // 2. Fall back to Head of Family member's phoneNumber / phone
    // 3. Otherwise "Not Available"
    const housePrimaryPhone = house.primaryContactPhone || house.mainPhone || house.contactPhone || house.primaryPhone;
    const headMemberPhone = headMember?.phoneNumber || headMember?.phone;

    let primaryPhone = "Not Available";
    if (housePrimaryPhone && String(housePrimaryPhone).trim() !== '') {
      primaryPhone = String(housePrimaryPhone).trim();
    } else if (headMemberPhone && String(headMemberPhone).trim() !== '') {
      primaryPhone = String(headMemberPhone).trim();
    }

    const rawFamilyName = house.familyName || 'CNRA Resident';
    const displayTitle = rawFamilyName.toLowerCase().includes('') 
      ? rawFamilyName 
      : `${rawFamilyName} `;

    return {
      id: house.id || `house_${idx}`,
      houseNumber: house.houseNumber || `CNRA-${idx + 100}`,
      familyName: rawFamilyName,
      houseName: displayTitle,
      address: house.address || 'Central Nagar',
      fullAddress: house.fullAddress || house.address || 'Central Nagar, CNRA Sector',
      mainPhone: primaryPhone,
      primaryContactPhone: primaryPhone,
      occupancyType: house.occupancyType || 'Owner',
      headName: headMember.fullName || 'Family Head',
      locationMark: house.locationMark || house.location_mark || house.landmark || '',
      location: house.location || { lat: 10.15476, lng: 76.346723 },
      members: members
    };
  });
};

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }
  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }
  componentDidCatch(error, errorInfo) {
    console.error("ErrorBoundary caught error:", error, errorInfo);
  }
  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center p-6 text-center">
          <div className="bg-slate-900 border border-slate-800 p-8 rounded-3xl max-w-md w-full shadow-2xl">
            <h2 className="text-xl font-bold text-emerald-400 mb-2">Portal Notice</h2>
            <p className="text-xs text-slate-400 mb-6 leading-relaxed">
              {this.state.error?.toString() || "An unexpected error occurred."}
            </p>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition-all shadow-lg shadow-emerald-500/20"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}

export function MainApp() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [houses, setHouses] = useState(() => processHousesData(RAW_MOCK_DATA));
  const [loading, setLoading] = useState(true);
  const [selectedHouse, setSelectedHouse] = useState(null);
  const [inspectedMember, setInspectedMember] = useState(null);

  // Search & Filters
  const [houseSearch, setHouseSearch] = useState('');
  const [memberSearch, setMemberSearch] = useState('');
  const [genderFilter, setGenderFilter] = useState('All');
  const [bloodFilter, setBloodFilter] = useState('All');
  const [relationFilter, setRelationFilter] = useState('All');
  const [viewMode, setViewMode] = useState('grid');

  // Pagination
  const [housePage, setHousePage] = useState(1);
  const [memberPage, setMemberPage] = useState(1);
  const itemsPerPage = 9;
  const membersPerPage = 12;

  useEffect(() => {
    let unsubscribeFirestore = null;
    let unsubscribeRtdb = null;

    try {
      if (rtdb) {
        const dbRef = ref(rtdb, 'cnra_houses');
        unsubscribeRtdb = onValue(dbRef, (snapshot) => {
          const val = snapshot.val();
          if (val) {
            const list = processHousesData(val);
            if (list.length > 0) setHouses(list);
          }
          setLoading(false);
        }, (error) => {
          console.warn("RTDB fallback triggered:", error);
          if (db) {
            const q = query(collection(db, 'cnra_houses'));
            unsubscribeFirestore = onSnapshot(q, (snapshot) => {
              if (!snapshot.empty) {
                const firestoreHouses = [];
                snapshot.forEach(doc => firestoreHouses.push({ id: doc.id, ...doc.data() }));
                setHouses(processHousesData(firestoreHouses));
              }
              setLoading(false);
            }, () => setLoading(false));
          } else {
            setLoading(false);
          }
        });
      } else {
        setLoading(false);
      }
    } catch (e) {
      console.warn("Firebase listener fallback:", e);
      setLoading(false);
    }

    const timer = setTimeout(() => setLoading(false), 300);
    return () => {
      clearTimeout(timer);
      if (unsubscribeRtdb) unsubscribeRtdb();
      if (unsubscribeFirestore) unsubscribeFirestore();
    };
  }, []);

  const allMembers = useMemo(() => {
    return houses.flatMap(house => {
      const membersList = normalizeMembers(house.members);
      return membersList.map(member => ({
        ...member,
        houseNumber: house.houseNumber || 'N/A',
        houseName: house.houseName || 'N/A',
        familyName: house.familyName || 'N/A',
        address: house.address || 'N/A',
        houseId: house.id || ''
      }));
    });
  }, [houses]);

  const stats = useMemo(() => {
    const totalHouses = houses.length;
    const totalMembers = allMembers.length;
    const bloodDonorsCount = allMembers.filter(m => m.bloodGroup && m.bloodGroup !== 'N/A' && m.bloodGroup !== '--').length;

    const maleCount = allMembers.filter(m => (m.gender || '').toLowerCase().trim() === 'male').length;
    const femaleCount = allMembers.filter(m => (m.gender || '').toLowerCase().trim() === 'female').length;

    const malePercent = totalMembers > 0 ? ((maleCount / totalMembers) * 100).toFixed(1) : '0';
    const femalePercent = totalMembers > 0 ? ((femaleCount / totalMembers) * 100).toFixed(1) : '0';

    return { 
      totalHouses, 
      totalMembers, 
      bloodDonorsCount, 
      maleCount, 
      femaleCount, 
      malePercent, 
      femalePercent 
    };
  }, [houses, allMembers]);

  const filteredHouses = useMemo(() => {
    return houses.filter(house => {
      const houseNum = (house.houseNumber || '').toLowerCase();
      const houseName = (house.houseName || '').toLowerCase();
      const familyName = (house.familyName || '').toLowerCase();
      const headName = (house.headName || '').toLowerCase();
      const address = (house.address || '').toLowerCase();
      const phone = (house.mainPhone || '').toLowerCase();
      const locationMark = (house.locationMark || '').toLowerCase();
      const term = houseSearch.toLowerCase();

      const matchHouseNum = houseNum.includes(term);
      const matchHouseName = houseName.includes(term);
      const matchFamilyName = familyName.includes(term);
      const matchHeadName = headName.includes(term);
      const matchAddress = address.includes(term);
      const matchPhone = phone.includes(term);
      const matchLocationMark = locationMark.includes(term);
      const matchMember = normalizeMembers(house.members).some(m => 
        (m?.fullName || m?.name || '').toLowerCase().includes(term)
      );

      return matchHouseNum || matchHouseName || matchFamilyName || matchHeadName || matchAddress || matchPhone || matchLocationMark || matchMember;
    });
  }, [houses, houseSearch]);

  const filteredMembers = useMemo(() => {
    return allMembers.filter(m => {
      const term = memberSearch.toLowerCase();
      const matchName = (m.fullName || m.name || '').toLowerCase().includes(term);
      const matchPhone = (m.phone || '').toLowerCase().includes(term);
      const matchHouse = (m.houseNumber || '').toLowerCase().includes(term) || (m.houseName || '').toLowerCase().includes(term);
      const matchEmail = (m.email || '').toLowerCase().includes(term);
      const matchOccupation = (m.occupation || '').toLowerCase().includes(term);

      const matchGender = genderFilter === 'All' || m.gender === genderFilter;
      const matchBlood = bloodFilter === 'All' || m.bloodGroup === bloodFilter;
      const matchRelation = relationFilter === 'All' || m.relationship === relationFilter;

      return (matchName || matchPhone || matchHouse || matchEmail || matchOccupation) && matchGender && matchBlood && matchRelation;
    });
  }, [allMembers, memberSearch, genderFilter, bloodFilter, relationFilter]);

  const paginatedHouses = useMemo(() => {
    const start = (housePage - 1) * itemsPerPage;
    return filteredHouses.slice(start, start + itemsPerPage);
  }, [filteredHouses, housePage]);

  const totalHousePages = Math.ceil(filteredHouses.length / itemsPerPage) || 1;

  const paginatedMembers = useMemo(() => {
    const start = (memberPage - 1) * membersPerPage;
    return filteredMembers.slice(start, start + membersPerPage);
  }, [filteredMembers, memberPage]);

  const totalMemberPages = Math.ceil(filteredMembers.length / membersPerPage) || 1;

  return (
    <div className="min-h-screen bg-[#070a12] text-slate-100 flex flex-col font-sans antialiased pb-20 md:pb-6 selection:bg-emerald-500 selection:text-slate-950">
      
      {/* Mobile App Header Bar */}
      <header className="bg-[#0b1120]/90 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-40 px-4 py-3 sm:px-6">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-emerald-400 to-teal-600 rounded-2xl flex items-center justify-center font-black text-slate-950 text-xl shadow-lg shadow-emerald-500/20">
              C
            </div>
            <div>
              <h1 className="font-bold text-base sm:text-lg tracking-tight text-white leading-tight">CNRA Association</h1>
              <p className="text-[11px] text-slate-400 font-medium">Residents Portal</p>
            </div>
          </div>


        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-5 flex-1 w-full space-y-6">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-24">
            <RefreshCwIcon className="w-8 h-8 text-emerald-400 animate-spin mb-3" />
            <p className="text-xs font-semibold text-slate-400 tracking-wide">Connecting to CNRA Directory...</p>
          </div>
        ) : (
          <>
            {/* Navigation Tabs Bar (Mobile Top/Desktop Clean) */}
            <nav className="flex bg-[#0f172a] p-1.5 rounded-2xl border border-slate-800 shadow-lg gap-1">
              {[
                { id: 'dashboard', label: 'Overview', icon: HomeIcon },
                { id: 'houses', label: 'Houses', icon: BuildingIcon, count: houses.length },
                { id: 'members', label: 'Members', icon: UsersIcon, count: allMembers.length }
              ].map(tab => {
                const IconComponent = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex-1 py-2.5 px-3 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all ${
                      isActive
                        ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
                    }`}
                  >
                    <IconComponent className="w-4 h-4" />
                    <span>{tab.label}</span>
                    {tab.count !== undefined && (
                      <span className={`px-1.5 py-0.5 text-[10px] rounded-full font-black ${
                        isActive ? 'bg-slate-950/20 text-slate-950' : 'bg-slate-800 text-slate-400'
                      }`}>
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>

            {/* TAB 1: DASHBOARD */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                {/* Hero Mobile App Card */}
                <div className="bg-gradient-to-br from-[#111c35] to-[#0d1527] p-6 rounded-3xl border border-slate-800 shadow-xl relative overflow-hidden">
                  <div className="relative z-10 space-y-2">
                    <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-widest bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
                      CNRA
                    </span>
                    <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">Welcome to CNRA Portal</h2>
                    <p className="text-xs sm:text-sm text-slate-400 max-w-lg leading-relaxed">
                      Official resident directory, family profiles, emergency contacts, and active blood donors list.
                    </p>
                  </div>
                </div>

                {/* Stat Cards Grid */}
                {}
                <div className="grid grid-cols-2 sm:grid-cols-2 gap-3 sm:gap-4">
                  <div className="bg-[#0f172a] p-4 sm:p-5 rounded-2xl border border-slate-800 shadow-md flex flex-col justify-between">
                    <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mb-3">
                      <BuildingIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Houses</p>
                      <p className="text-2xl font-black text-white mt-0.5">{stats.totalHouses}</p>
                    </div>
                  </div>

                  <div className="bg-[#0f172a] p-4 sm:p-5 rounded-2xl border border-slate-800 shadow-md flex flex-col justify-between">
                    <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center mb-3">
                      <UsersIcon className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">Total Members</p>
                      <p className="text-2xl font-black text-white mt-0.5">{stats.totalMembers}</p>
                    </div>
                  </div>


                </div>

                {/* Male to Female Ratio Card */}
                <div className="bg-[#0f172a] p-5 rounded-2xl border border-slate-800 shadow-md space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-bold text-white tracking-tight">Gender Distribution & Ratio</h3>
                      <p className="text-[11px] text-slate-400">Male vs Female demographics among registered residents</p>
                    </div>

                  </div>

                  {/* Dual Color Visual Bar */}
                  <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden flex">
                    <div 
                      className="bg-blue-500 h-full transition-all duration-500" 
                      style={{ width: `${stats.malePercent}%` }}
                      title={`Male: ${stats.malePercent}%`}
                    />
                    <div 
                      className="bg-pink-500 h-full transition-all duration-500" 
                      style={{ width: `${stats.femalePercent}%` }}
                      title={`Female: ${stats.femalePercent}%`}
                    />
                  </div>

                  {/* Detailed Count and Percentage Tiles */}
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div className="bg-[#131b2e] p-3 rounded-xl border border-slate-800/80 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-blue-500 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-white">Male</p>
                          <p className="text-[11px] font-medium text-slate-400">{stats.maleCount} members</p>
                        </div>
                      </div>
                      <span className="text-sm font-black text-blue-400 font-mono">{stats.malePercent}%</span>
                    </div>

                    <div className="bg-[#131b2e] p-3 rounded-xl border border-slate-800/80 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full bg-pink-500 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-white">Female</p>
                          <p className="text-[11px] font-medium text-slate-400">{stats.femaleCount} members</p>
                        </div>
                      </div>
                      <span className="text-sm font-black text-pink-400 font-mono">{stats.femalePercent}%</span>
                    </div>
                  </div>
                </div>

                {/* Quick Family Directory Grid */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-bold text-white tracking-tight">Recent House Profiles</h3>
                    <button
                      onClick={() => setActiveTab('houses')}
                      className="text-xs font-bold text-emerald-400 hover:underline flex items-center gap-1"
                    >
                      View All ({houses.length}) <ChevronRightIcon className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {houses.slice(0, 4).map(house => {
                      const membersList = normalizeMembers(house.members);
                      return (
                        <div
                          key={house.id}
                          className="bg-[#0f172a] p-5 rounded-2xl border border-slate-800/80 hover:border-emerald-500/40 transition-all shadow-md flex flex-col justify-between"
                        >
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="px-2.5 py-1 bg-[#063326] text-emerald-400 font-bold uppercase rounded-lg text-xs border border-emerald-800/60 tracking-wider">
                                {house.houseNumber}
                              </span>
                              <span className="text-[11px] font-semibold text-slate-400 bg-slate-800/60 px-2 py-0.5 rounded-md">
                                {membersList.length} Members
                              </span>
                            </div>

                            <div>
                              <h4 className="text-base font-bold text-white">{house.houseName}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <p className="text-xs text-slate-400 flex items-center gap-1 truncate">
                                  <MapPinIcon className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                                  <span className="truncate">{house.address}</span>
                                </p>
                                {(house.locationMark || house.location?.lat) && (
                                  <span 
                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full shrink-0 max-w-[130px] truncate"
                                    title={house.locationMark || "Location"}
                                  >
                                    <MapPinIcon className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                                    <span className="truncate">{house.locationMark || 'Location'}</span>
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between">
                            {house.mainPhone && house.mainPhone !== 'Not Available' ? (
                              <a
                                href={`tel:${house.mainPhone}`}
                                className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1 hover:underline"
                              >
                                <PhoneIcon className="w-3.5 h-3.5" /> {house.mainPhone}
                              </a>
                            ) : (
                              <span className="text-xs font-mono font-medium text-slate-500 flex items-center gap-1">
                                <PhoneIcon className="w-3.5 h-3.5" /> Not Available
                              </span>
                            )}

                            <button
                              onClick={() => setSelectedHouse(house)}
                              className="px-3 py-1.5 bg-[#182238] hover:bg-emerald-500 hover:text-slate-950 text-emerald-400 text-xs font-bold rounded-xl border border-slate-700 transition-all flex items-center gap-1"
                            >
                              <EyeIcon className="w-3.5 h-3.5" /> Details
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            )}

            {/* TAB 2: HOUSES DIRECTORY */}
            {activeTab === 'houses' && (
              <div className="space-y-4">
                {/* Search & Layout Toggle Bar */}
                <div className="bg-[#0f172a] p-3.5 rounded-2xl border border-slate-800 shadow-md flex flex-col sm:flex-row gap-3 items-center justify-between">
                  <div className="relative w-full sm:w-80">
                    <SearchIcon className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Search house no, family, address, phone..."
                      value={houseSearch}
                      onChange={(e) => {
                        setHouseSearch(e.target.value);
                        setHousePage(1);
                      }}
                      className="w-full pl-10 pr-4 py-2 bg-[#070a12] border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-all"
                    />
                  </div>

                  <div className="flex items-center justify-between w-full sm:w-auto gap-3">
                    <div className="bg-[#070a12] p-1 rounded-xl flex items-center gap-1 border border-slate-800">
                      <button
                        onClick={() => setViewMode('grid')}
                        className={`p-1.5 rounded-lg text-xs font-medium transition-all ${
                          viewMode === 'grid' ? 'bg-[#182238] text-emerald-400 shadow-sm' : 'text-slate-400 hover:text-white'
                        }`}
                        title="Grid View"
                      >
                        <GridIcon className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setViewMode('list')}
                        className={`p-1.5 rounded-lg text-xs font-medium transition-all ${
                          viewMode === 'list' ? 'bg-[#182238] text-emerald-400 shadow-sm' : 'text-slate-400 hover:text-white'
                        }`}
                        title="List View"
                      >
                        <ListIcon className="w-4 h-4" />
                      </button>
                    </div>

                    <span className="text-xs font-medium text-slate-400">
                      {filteredHouses.length} Houses
                    </span>
                  </div>
                </div>

                {filteredHouses.length === 0 ? (
                  <div className="bg-[#0f172a] p-12 rounded-3xl border border-slate-800 text-center text-slate-400 space-y-2">
                    <BuildingIcon className="w-10 h-10 text-slate-600 mx-auto" />
                    <p className="font-bold text-slate-300 text-sm">No house records found</p>
                    <p className="text-xs text-slate-500">Try adjusting search term</p>
                  </div>
                ) : viewMode === 'grid' ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    {paginatedHouses.map(house => {
                      const membersList = normalizeMembers(house.members);
                      return (
                        <div
                          key={house.id}
                          className="bg-[#0f172a] p-5 rounded-2xl border border-slate-800/80 hover:border-emerald-500/40 transition-all shadow-md flex flex-col justify-between"
                        >
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="px-2.5 py-1 bg-[#063326] text-emerald-400 font-bold uppercase rounded-lg text-xs border border-emerald-800/60 tracking-wider">
                                {house.houseNumber}
                              </span>
                              <span className="text-[11px] font-semibold text-slate-400 bg-slate-800/60 px-2 py-0.5 rounded-md">
                                {membersList.length} Members
                              </span>
                            </div>

                            <div>
                              <h4 className="text-base font-bold text-white">{house.houseName}</h4>
                              <div className="flex items-center gap-2 mt-1">
                                <p className="text-xs text-slate-400 flex items-center gap-1 truncate">
                                  <MapPinIcon className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                                  <span className="truncate">{house.address}</span>
                                </p>
                                {(house.locationMark || house.location?.lat) && (
                                  <span 
                                    className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full shrink-0 max-w-[130px] truncate"
                                    title={house.locationMark || "Location"}
                                  >
                                    <MapPinIcon className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                                    <span className="truncate">{house.locationMark || 'Location'}</span>
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>

                          <div className="mt-4 pt-4 border-t border-slate-800/80 flex items-center justify-between">
                            {house.mainPhone && house.mainPhone !== 'Not Available' ? (
                              <a
                                href={`tel:${house.mainPhone}`}
                                className="text-xs font-mono font-bold text-emerald-400 flex items-center gap-1 hover:underline"
                              >
                                <PhoneIcon className="w-3.5 h-3.5" /> {house.mainPhone}
                              </a>
                            ) : (
                              <span className="text-xs font-mono font-medium text-slate-500 flex items-center gap-1">
                                <PhoneIcon className="w-3.5 h-3.5" /> Not Available
                              </span>
                            )}

                            <button
                              onClick={() => setSelectedHouse(house)}
                              className="px-3 py-1.5 bg-[#182238] hover:bg-emerald-500 hover:text-slate-950 text-emerald-400 text-xs font-bold rounded-xl border border-slate-700 transition-all flex items-center gap-1"
                            >
                              <EyeIcon className="w-3.5 h-3.5" /> Details
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="bg-[#0f172a] rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-[#0b1120] border-b border-slate-800 text-slate-400 text-[11px] uppercase tracking-wider font-semibold">
                            <th className="p-4">House No</th>
                            <th className="p-4">Family Name</th>
                            <th className="p-4">Address</th>

                            <th className="p-4 text-right">Action</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
                          {paginatedHouses.map(house => (
                            <tr key={house.id} className="hover:bg-[#182238]/40 transition-colors">
                              <td className="p-4 font-bold uppercase text-emerald-400">{house.houseNumber}</td>
                              <td className="p-4 font-bold text-white">{house.houseName}</td>
                              <td className="p-4 text-slate-400 max-w-xs truncate">
                                <div className="flex items-center gap-2">
                                  
                                  {(house.locationMark || house.location?.lat) && (
                                    <span 
                                      className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold rounded-full shrink-0 max-w-[130px] truncate"
                                      title={house.locationMark || "Location"}
                                    >
                                      <MapPinIcon className="w-2.5 h-2.5 text-emerald-400 shrink-0" />
                                      <span className="truncate">{house.locationMark || 'Location'}</span>
                                    </span>
                                  )}
                                </div>
                              </td>

                              <td className="p-4 text-right">
                                <button
                                  onClick={() => setSelectedHouse(house)}
                                  className="px-3 py-1.5 bg-[#182238] text-emerald-400 hover:bg-emerald-500 hover:text-slate-950 rounded-lg font-bold transition-all border border-slate-700"
                                >
                                  View
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* Pagination Controls */}
                {totalHousePages > 1 && (
                  <div className="flex items-center justify-between bg-[#0f172a] p-3.5 rounded-2xl border border-slate-800 shadow-md">
                    <button
                      onClick={() => setHousePage(p => Math.max(p - 1, 1))}
                      disabled={housePage === 1}
                      className="px-3.5 py-1.5 bg-[#070a12] border border-slate-800 rounded-xl text-xs font-semibold text-slate-300 disabled:opacity-40 flex items-center gap-1 hover:bg-[#182238]"
                    >
                      <ChevronLeftIcon className="w-4 h-4" /> Prev
                    </button>
                    <span className="text-xs font-medium text-slate-400">
                      Page {housePage} of {totalHousePages}
                    </span>
                    <button
                      onClick={() => setHousePage(p => Math.min(p + 1, totalHousePages))}
                      disabled={housePage === totalHousePages}
                      className="px-3.5 py-1.5 bg-[#070a12] border border-slate-800 rounded-xl text-xs font-semibold text-slate-300 disabled:opacity-40 flex items-center gap-1 hover:bg-[#182238]"
                    >
                      Next <ChevronRightIcon className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: MEMBERS DIRECTORY */}
            {activeTab === 'members' && (
              <div className="space-y-4">
                {/* Search & Mobile Filter Sheet Bar */}
                <div className="bg-[#0f172a] p-4 rounded-2xl border border-slate-800 shadow-md space-y-3">
                  <div className="relative w-full">
                    <SearchIcon className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      placeholder="Search member name, email, phone, house..."
                      value={memberSearch}
                      onChange={(e) => {
                        setMemberSearch(e.target.value);
                        setMemberPage(1);
                      }}
                      className="w-full pl-10 pr-4 py-2.5 bg-[#070a12] border border-slate-800 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 transition-all"
                    />
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <select
                      value={genderFilter}
                      onChange={(e) => setGenderFilter(e.target.value)}
                      className="py-2 px-2.5 bg-[#070a12] border border-slate-800 rounded-xl text-[11px] font-medium text-slate-300 focus:outline-none focus:border-emerald-500"
                    >
                      <option value="All">All Genders</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>

                    <select
                      value={bloodFilter}
                      onChange={(e) => setBloodFilter(e.target.value)}
                      className="py-2 px-2.5 bg-[#070a12] border border-slate-800 rounded-xl text-[11px] font-medium text-slate-300 focus:outline-none focus:border-emerald-500"
                    >
                      <option value="All">Blood Group</option>
                      {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => (
                        <option key={bg} value={bg}>{bg}</option>
                      ))}
                    </select>

                    <select
                      value={relationFilter}
                      onChange={(e) => setRelationFilter(e.target.value)}
                      className="py-2 px-2.5 bg-[#070a12] border border-slate-800 rounded-xl text-[11px] font-medium text-slate-300 focus:outline-none focus:border-emerald-500"
                    >
                      <option value="All">Relationship</option>
                      {['Head of Family', 'Spouse', 'Son', 'Daughter'].map(rel => (
                        <option key={rel} value={rel}>{rel}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {filteredMembers.length === 0 ? (
                  <div className="bg-[#0f172a] p-12 rounded-3xl border border-slate-800 text-center text-slate-400 space-y-2">
                    <UsersIcon className="w-10 h-10 text-slate-600 mx-auto" />
                    <p className="font-bold text-slate-300 text-sm">No members match criteria</p>
                    <p className="text-xs text-slate-500">Try resetting active filters</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {paginatedMembers.map(m => (
                      <div
                        key={m.id || m.fullName}
                        className="bg-[#0f172a] p-4 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all shadow-md flex items-center justify-between"
                      >
                        <div className="flex items-center gap-3 min-w-0">
                          {m.photo ? (
                            <img src={m.photo} alt={m.fullName} className="w-12 h-12 rounded-2xl object-cover border border-slate-700 shrink-0" />
                          ) : (
                            <div className="w-12 h-12 rounded-2xl bg-[#182238] border border-slate-700 text-emerald-400 font-bold flex items-center justify-center text-base shrink-0">
                              {m.fullName ? m.fullName.charAt(0) : 'R'}
                            </div>
                          )}

                          <div className="min-w-0">
                            <h4 className="font-bold text-white text-sm truncate">{m.fullName}</h4>
                            
                            <p className="text-[11px] text-slate-400 truncate"><span className="text-slate-200 font-semibold">{m.houseName}</span> <span className="text-emerald-400 font-bold uppercase">({m.houseNumber})</span></p>
                            
                            {m.bloodGroup && m.bloodGroup !== 'N/A' && m.bloodGroup !== '--' && (
                              <span className="inline-flex hidden items-center gap-1 mt-1 text-[10px] font-black text-rose-400 bg-rose-950/60 border border-rose-800/40 px-1.5 py-0.2 rounded">
                                <DropletIcon className="w-2.5 h-2.5 text-rose-500" /> {m.bloodGroup}
                              </span>
                            )}
                          </div>
                        </div>

                        <button
                          onClick={() => setInspectedMember(m)}
                          className="p-2.5 bg-[#182238] hover:bg-emerald-500 hover:text-slate-950 text-slate-300 rounded-xl transition-all border border-slate-700 shrink-0 ml-2"
                          title="View Profile"
                        >
                          <EyeIcon className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Pagination Controls */}
                {totalMemberPages > 1 && (
                  <div className="flex items-center justify-between bg-[#0f172a] p-3.5 rounded-2xl border border-slate-800 shadow-md">
                    <button
                      onClick={() => setMemberPage(p => Math.max(p - 1, 1))}
                      disabled={memberPage === 1}
                      className="px-3.5 py-1.5 bg-[#070a12] border border-slate-800 rounded-xl text-xs font-semibold text-slate-300 disabled:opacity-40 flex items-center gap-1 hover:bg-[#182238]"
                    >
                      <ChevronLeftIcon className="w-4 h-4" /> Prev
                    </button>
                    <span className="text-xs font-medium text-slate-400">
                      Page {memberPage} of {totalMemberPages}
                    </span>
                    <button
                      onClick={() => setMemberPage(p => Math.min(p + 1, totalMemberPages))}
                      disabled={memberPage === totalMemberPages}
                      className="px-3.5 py-1.5 bg-[#070a12] border border-slate-800 rounded-xl text-xs font-semibold text-slate-300 disabled:opacity-40 flex items-center gap-1 hover:bg-[#182238]"
                    >
                      Next <ChevronRightIcon className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </main>

      {/* HOUSE DETAILS MODAL (Exact requested design matching dark theme) */}
      {selectedHouse && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-[#0b1120] rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-800 text-slate-100 flex flex-col my-auto max-h-[90vh]">
            
            {/* Modal Header */}
            <div className="p-5 sm:p-6 border-b border-slate-800/80 flex items-start justify-between bg-[#0b1120] shrink-0">
              <div className="space-y-1">
                <span className="px-2.5 py-0.5 bg-[#063326] text-emerald-400 font-bold uppercase rounded text-xs border border-emerald-800/60 inline-block tracking-wider">
                  {selectedHouse.houseNumber}
                </span>
                <h2 className="text-2xl font-bold text-white tracking-tight">{selectedHouse.houseName}</h2>
                <p className="text-xs text-slate-400 font-medium">{selectedHouse.address}</p>
              </div>

              <button 
                onClick={() => setSelectedHouse(null)}
                className="p-2 bg-[#182238] text-slate-400 hover:text-white rounded-xl border border-slate-700 transition-colors shrink-0"
              >
                <XIcon className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-5 sm:p-6 space-y-5 bg-[#0b1120] overflow-y-auto">
              {/* House Info Card Box */}
              <div className="bg-[#131b2e] p-4 rounded-2xl border border-slate-800/80 space-y-2.5 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Primary Contact:</span>
                  {selectedHouse.mainPhone && selectedHouse.mainPhone !== 'Not Available' ? (
                    <a href={`tel:${selectedHouse.mainPhone}`} className="font-bold text-emerald-400 font-mono text-xs sm:text-sm hover:underline">
                      {selectedHouse.mainPhone}
                    </a>
                  ) : (
                    <span className="font-medium text-slate-500 font-mono text-xs sm:text-sm">
                      Not Available
                    </span>
                  )}
                </div>
                {selectedHouse.locationMark && (
                  <div className="flex justify-between items-center">
                    <span className="text-slate-400">Location Mark:</span>
                    <span className="font-bold text-emerald-400 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded-full text-[11px] inline-flex items-center gap-1">
                      <MapPinIcon className="w-3 h-3 text-emerald-400" />
                      {selectedHouse.locationMark}
                    </span>
                  </div>
                )}

                <div className="flex justify-between items-start pt-1 border-t border-slate-800/60">
                  <span className="text-slate-400 shrink-0">Address:</span>
                  <span className="font-semibold text-slate-200 text-right max-w-[230px]">
                    {selectedHouse.fullAddress}
                  </span>
                </div>
              </div>

              {/* Open Google Maps Button */}
              {selectedHouse.location && selectedHouse.location.lat && (
                <a
                  href={`https://www.google.com/maps/search/?api=1&query=${selectedHouse.location.lat},${selectedHouse.location.lng}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2.5 bg-[#063326] hover:bg-emerald-600 text-emerald-300 hover:text-white rounded-xl text-xs font-bold border border-emerald-800/60 transition-all flex items-center justify-center gap-2 shadow-sm"
                >
                  <MapPinIcon className="w-4 h-4 text-emerald-400" />
                  <span>Open in Google Maps</span>
                  <ExternalLinkIcon className="w-3.5 h-3.5" />
                </a>
              )}

              {/* Family Members Section */}
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white tracking-wide">
                  Family Members ({normalizeMembers(selectedHouse.members).length})
                </h3>

                <div className="space-y-2.5">
                  {normalizeMembers(selectedHouse.members).map((m) => (
                    <div 
                      key={m.id || m.fullName} 
                      className="p-3.5 bg-[#131b2e] border border-slate-800/80 rounded-2xl flex items-center justify-between hover:border-slate-700 transition-all"
                    >
                      <div className="flex items-center gap-3">
                        {m.photo ? (
                          <img 
                            src={m.photo} 
                            alt={m.fullName} 
                            className="w-10 h-10 rounded-xl object-cover border border-slate-700 shrink-0"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-xl bg-[#182238] border border-slate-700 text-emerald-400 font-bold flex items-center justify-center text-sm shrink-0">
                            {m.fullName ? m.fullName.charAt(0) : 'M'}
                          </div>
                        )}

                        <div>
                          <h4 className="font-bold text-white text-xs sm:text-sm">{m.fullName}</h4>
                          <p className="text-[11px] text-slate-400 mt-0.5">
                            {m.relationship}
                            {m.bloodGroup && m.bloodGroup !== 'N/A' && m.bloodGroup !== '--' && (
                              <span className="ml-1.5 font-bold text-rose-400">
                                • Blood: <span className="text-rose-400 font-black">{m.bloodGroup}</span>
                              </span>
                            )}
                          </p>
                        </div>
                      </div>

                      <button
                        onClick={() => setInspectedMember({ ...m, houseNumber: selectedHouse.houseNumber, houseName: selectedHouse.houseName })}
                        className="p-2 bg-[#182238] text-slate-300 hover:text-white hover:bg-emerald-500 hover:text-slate-950 rounded-xl border border-slate-700 transition-all"
                        title="View Details"
                      >
                        <EyeIcon className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MEMBER INSPECTION MODAL */}
      {inspectedMember && (
        <div className="fixed inset-0 z-[60] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#0b1120] rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-800 text-slate-100 relative">
            <button 
              onClick={() => setInspectedMember(null)}
              className="absolute top-4 right-4 p-2 bg-[#182238] text-slate-400 hover:text-white rounded-xl border border-slate-700"
            >
              <XIcon className="w-4 h-4" />
            </button>

            <div className="flex flex-col items-center text-center">
              {inspectedMember.photo ? (
                <img src={inspectedMember.photo} alt={inspectedMember.fullName} className="w-20 h-20 rounded-2xl object-cover border-2 border-emerald-500 shadow-lg mb-3" />
              ) : (
                <div className="w-20 h-20 rounded-2xl bg-[#182238] text-emerald-400 font-bold text-2xl flex items-center justify-center border border-slate-700 mb-3">
                  {inspectedMember.fullName ? inspectedMember.fullName.charAt(0) : 'R'}
                </div>
              )}

              <h3 className="text-lg font-bold text-white">{inspectedMember.fullName}</h3>
              <p className="text-xs text-slate-400 mt-0.5">{inspectedMember.houseName} <span className="uppercase">({inspectedMember.houseNumber})</span></p>

              {inspectedMember.phone && (
                <a href={`tel:${inspectedMember.phone}`} className="mt-2 font-mono text-emerald-400 text-xs font-bold inline-flex items-center gap-1 hover:underline bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                  <PhoneIcon className="w-3.5 h-3.5" /> {inspectedMember.phone}
                </a>
              )}

              <div className="w-full mt-4 bg-[#131b2e] p-4 rounded-2xl border border-slate-800/80 text-xs space-y-2.5 text-left">
                <div className="flex justify-between border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Gender</span>
                  <span className="font-semibold text-white">{inspectedMember.gender || 'N/A'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Relationship</span>
                  <span className="font-semibold text-white">{inspectedMember.relationship || 'N/A'}</span>
                </div>
                {inspectedMember.dateOfBirth && (
                  <div className="flex justify-between border-b border-slate-800/80 pb-2">
                    <span className="text-slate-400">DOB / Age</span>
                    <span className="font-semibold text-white">{inspectedMember.dateOfBirth} {inspectedMember.age ? `(${inspectedMember.age} yrs)` : ''}</span>
                  </div>
                )}
                <div className="flex justify-between border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Blood Group</span>
                  <span className="font-bold text-rose-400">{inspectedMember.bloodGroup || '--'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-800/80 pb-2">
                  <span className="text-slate-400">Occupation</span>
                  <span className="font-semibold text-slate-200">{inspectedMember.occupation || 'N/A'}</span>
                </div>
                {inspectedMember.email && (
                  <div className="flex justify-between border-b border-slate-800/80 pb-2">
                    <span className="text-slate-400">Email</span>
                    <span className="font-semibold text-slate-300 truncate max-w-[170px]">{inspectedMember.email}</span>
                  </div>
                )}
                {inspectedMember.notes && (
                  <div className="flex justify-between pt-0.5">
                    <span className="text-slate-400">Notes</span>
                    <span className="font-semibold text-amber-400 text-right">{inspectedMember.notes}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <MainApp />
    </ErrorBoundary>
  );
}